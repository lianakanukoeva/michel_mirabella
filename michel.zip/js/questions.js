$(function() {
    $(".comments__more").click(function() {
        $(".comments__chat").toggleClass('active');
    });
});